
// console.log("hello js");
// let arr=[1,2,3,4,5]
// for(let i=0;i<arr.length;i++){
//     console.log(arr[i]);
// }

// for(const i of arr){
//     console.log(i)
// }

// for(const j in arr){
//     console.log(j);
// }

