// 1)accept a number from the user and check if it is even or odd
// let num = prompt("Enter the number");
// if(num%2==0){
//     alert("the number is even");
// }
// else{
//     alert("the number is odd");
// }


// 2)const name = prompt("Enter Name:");
// const age = prompt("Enter Age:");
// const phone = prompt("Enter Phone:");
// alter("Name:"+name+"Age"+age+"phoneNumber:-"+phone)


// 3)accept N number subject marks individually
// Print Total Marks Achieved.
// Print Percentage

// let N = (prompt("Enter the total number of subjects:"));
// let marks = [];
// let totalMarks = 0;

// for (let i = 0; i < N; i++) {
//    let mark =(prompt("Enter mark for subject :"));
//    marks.push(mark);
//    totalMarks += mark;
// }

// let percentage = (totalMarks / (N * 100)) * 100;

// console.log("Marks entered:", marks);
// console.log("Total Marks Achieved:", totalMarks);
// console.log("Percentage:", percentage);


// 4)console log will print 1 to 10
// let num=prompt("Enter the number");
// for(let i=1;i<=num;i++){
//     console.log(i);
// }

// 5)even odd
// let num=prompt("enter the number")
// let even=[];
// let odd=[];
// for(let i=0;i<=num;i++){
//     if(i%2==0){
//         even.push(i);
//     }
//     else{
//         odd.push(i);
//     }
// }
// console.log(even);
// console.log(odd);



// 6)Fibonacci series
// let n = prompt("Range:") 
// let a = 0, b = 1;
// while (a <= n) {
//   console.log(a);
//   let nextTerm = a + b;
//   a = b;
//   b = nextTerm;
// }

// 7)prints the factorial of the given user input.
//  let num = parseInt(prompt("Enter Number"));
// let fact = 1;

// if (num < 0) {
//     console.log("Factorial is not for negative numbers.");
// } else {
//     for (let i = 1; i <= num; i++) {
//         fact *= i; 
//     }
//     console.log("The factorial of"+num +"is" + fact);
// }


// 8) reverse of a given string
// let str=prompt("Enter String");

// let Rstr="";
// for(let i=str.length;i>=0;i--){
//     Rstr+=str.charAt(i);
// }
// console.log(Rstr);

// 9)Replace word with other 

// let sentence = prompt("Enter your sentence:");
// let instruction = prompt("Enter the word to replace and  new word (format: word|newword):");

// if (instruction.includes("|")) {
//     let parts = instruction.split("|");
//     let replaceWord = parts[0];
//     let replaceWith = parts[1];

//     let result = sentence.split(replaceWord).join(replaceWith);

//     alert("Result: " + result);
//     console.log("Result:", result);
    
// } else {
//     alert("wrong format");
// }

// 10)repeated letter count +letter
// let str=prompt("enter string");
// let strArray=[];
// for()

// 11)position of an array ******
// let N = parseInt(prompt("Enter length of array"));
// let arr = []; 

// for (let i = 0; i < N; i++) {
//    let ele = prompt("Enter Array Elements :");
//    arr.push(ele);
// }

// let xele = prompt("Enter finding element :");

// function findPosition(target, array) {
//     let count=0;
//     for (let j = 0; j < array.length; j++) {
//     if (array[j] == target) {
//         count++;
//     }
//     if (count > 1) {
//         return 2;
//         } 
//     else if (count === 1) {
//         return j;
//     }
//     return -1;
// }
// }

// console.log("Result:", findPosition(xele, arr));

// 12)leaderfind
//  let arr=[16,17,4,3,5,2];
// function findLeader(Array){
//     let leaderArray=[];
// for(let i=0;i<Array.length;i++){
//     // console.log(arr[i] , 'inital')
//     // console.log(arr[i+1] , 'next ')
//     if(i<Array.length && arr[i]>=arr[i+1]){
//         leaderArray.push(arr[i]);
//     }
// }
// return leaderArray;
// }
// function findLeader(Array){
//     let leaderArray=[];
//     for(let i=arr.length-1;i>=0;i--){
//         if(arr[i]>arr[i-1]){
//             leaderArray.push(arr[i]);
//         }
//      }
    
//     return leaderArray;
// }
//  console.log("Result",findLeader(arr));


// 13) even
// let gArr=[5,10,9,45,89,81,74,36];
// let evenArr=[];
// for(let i=0;i<gArr.length;i++){
//     if(gArr[i]%2==0){
//         evenArr.push(gArr[i]);
//     }
// }
// console.log(evenArr);

//14)good morning
// function displayGreetingAlert() {
//   let date = new Date();
//   let time = date.getHours();

//   if (time < 10) {
//     alert("Good morning");
//   } else {
//     alert("Good day");
//   }
// }
// displayGreetingAlert();

// 15)Math.floor(Math.random() * 11);
// let number=Math.floor(Math.random() * 11);
// console.log(number);
// if (number !== 0) { 
//     if (number % 4 === 0) {
//         console.log(number + " is divisible by 4");
//     }
//     if (number % 3 === 0) {
//         console.log(number + " is divisible by 3");
//     }
//     if (number % 7 === 0) {
//         console.log(number + " is divisible by 7");
//     }
    
//     if (number % 4 !== 0 && number % 3 !== 0 && number % 7 !== 0) {
//         console.log(number + " is not divisible by 4, 3, or 7");
//     }
// }

// 16)dayname
// let dayNumber = new Date().getDay();
// let dayName;

// switch (dayNumber) {
//   case 0:
//     dayName = "Sunday";
//     break;
//   case 1:
//     dayName = "Monday";
//     break;
//   case 2:
//     dayName = "Tuesday";
//     break;
//   case 3:
//     dayName = "Wednesday";
//     break;
//   case 4:
//     dayName = "Thursday";
//     break;
//   case 5:
//     dayName = "Friday";
//     break;
//   case 6:
//     dayName = "Saturday";
//     break;
//   default:
//     dayName = "Unknown Day";
// }
// console.log(dayName);

// 17)
// function numberToWords() {
//     let num;
//     let isValid = false;

//     while (!isValid) {
//         let input = prompt("Please enter a number between 21 and 100:");
//         num = parseInt(input);

//         if (num >= 21 && num <= 100) {
//             isValid = true;
//         } else {
//             alert("Invalid input.");
//         }
//     }

//     const ones = ["", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"];
//     const tens = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"];

//     let result = "";
//     if (num === 100) {
//         result = "one hundred";
//     } else {
//         let tenPart = Math.floor(num / 10);
//         let unitPart = num % 10;
        
//         if (unitPart !== 0) {
//     result = tens[tenPart] + " " + ones[unitPart];
//     }
//      else {
//     result = tens[tenPart];
//     }
//     }
//     console.log(`Input: ${num} = ${result}`);
//     alert(`${num} = ${result}`);
// }

// numberToWords();

// 18)
// function customSort(arr) {
// let n = arr.length;
//     for (let i = 0; i < n; i++) {
//         for (let j = 0; j < n - i - 1; j++) {
//             if (arr[j] > arr[j + 1]) {
//                 let temp = arr[j];
//                 arr[j] = arr[j + 1];
//                 arr[j + 1] = temp;
//             }
//         }
//     }  
//     alert("Sorted Array: " + arr.join(", "));
// }

// const myNumbers = [45,12,89,7,33,2];
// customSort(myNumbers);

// 19)
// let start=35;

// while(start>=35&&start<100){
//     start++;
//     console.log(start);
// }

// 21)




