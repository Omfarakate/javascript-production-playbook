// // let nums = [7,8,3,4,15,13,4,1];
// // nums.sort((a, b) => a - b);

// // let arr = [];

// // let left = 0;
// // let right = nums.length - 1;

// // while (left < right) {
// //     let x = nums[right];
// //     let y = nums[left];

// //     let z = (x + y) / 2;
// //     arr.push(z);

// //     left++;
// //     right--;
// // }
// // console.log(arr);


// // let items = [["phone","blue","pixel"],["computer","silver","lenovo"],["phone","gold","iphone"]];
// // let ruleKey = "color"; 
// // let ruleValue = "silver";

// // let innerarr=[]
// // let x=0;
// // for(let i=0;i<items.length;i++){

// //     innerarr=items[i];
// //     console.log(innerarr);
// //     for(let j=0;j<innerarr.length;j++){
// //         if(innerarr[i]===ruleKey&&innerarr[i]===ruleValue){
// //             x++;
// //         }
// //     }
// // }
// // console.log(x);

// let nums = [10,10,3,7,6];
// let sum=0,x=0,diff=0;
// let k=0;
// for(let i=0;i<nums.length;i++){
//     sum+=nums[i];
//     for (let index = i+1; index < nums.length; index++) {
//         k=0;
//         k+=nums[index];
        
//     }
//      diff=k-nums[i];
//         if(diff%2===0){
//         x++;
//         }
//         console.log(diff);
    
   

// }
// console.log(x);


let names = ["Mary","John","Emma"] ;
let heights = [180,165,170];
let max=0;
let name;
let namesnew=[];
let heightsnew=[];
// for(let i=0;i<heights.length;i++){
//     while(heights.lenght!=0){
//         if(max<heights[i]){
//         max=heights[i];
//         heights.pop(heights[i]);
//         name=names[i];
//         heightsnew.push(max);
//         namesnew.push(name);
//     }
//     }
    


// }
// console.log(namesnew);
// console.log(max)

const newarray=names.map((name,i)=>{
    name,
    i= heights[i]
})
console.log(newarray);

// const namesx = ["Alice", "Bob", "Charlie"];
// const ages = [25, 30, 35];

// const people = names.map((name, index) => ({
//   name,
//   age: ages[index]
// }));

// console.log(people);