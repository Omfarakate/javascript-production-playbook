const divId=document.getElementById("”container_id”");
const allInnerSpans=divId.querySelectorAll("*");
for (let i = 0; i < allInnerSpans.length; i++) {
  let newContainer=allInnerSpans[i].tagName; 
  console.log(newContainer);
}