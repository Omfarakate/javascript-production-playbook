let range = document.getElementById("2004");
let output = document.getElementById("range");

range.addEventListener("mouseover", function() {
    output.textContent=`${output}`
  });


