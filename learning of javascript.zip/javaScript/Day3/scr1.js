let button= document.getElementsByClassName("my-btn");

button[0].addEventListener("click", function() {
let num_val = document.getElementById("num").value; 
console.log("Input num:", num_val);

    let a = 0, b = 1;
    while (a <= num_val) {
        console.log(a);
        let nextTerm = a + b;
        a = b;
        b = nextTerm;
        
    }
});


