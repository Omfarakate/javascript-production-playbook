let btn1=document.getElementById("btn_1");

btn1.addEventListener("click", function(){
    console.log("You clicked btn1");
    let btn1Value=document.getElementById("btn_1").value;
    alert("You clicked button 1"+" which has value  "+ btn1Value);
})

let btn2=document.getElementById("btn_2");

btn2.addEventListener("click", function(){
    console.log("You clicked btn2");
    let btn2Value=document.getElementById("btn_2").value;
    alert("You clicked button 2"+" which has value  "+ btn2Value);
})

let btn3=document.getElementById("btn_3");

btn3.addEventListener("click", function(){
    console.log("You clicked btn3");
    let btn3Value=document.getElementById("btn_3").value;
    alert("You clicked button 3"+" which has value  "+ btn3Value);
})