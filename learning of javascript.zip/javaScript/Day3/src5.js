let btn=document.getElementsByClassName("border_class");
button=document.getElementById("btnId");
btn[0].addEventListener("click",function(){
    btn[0].style.width="50px";
    btn[0].style.height="50px";
})