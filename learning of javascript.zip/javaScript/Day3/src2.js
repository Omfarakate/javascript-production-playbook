

// let red=document.getElementById("first");
// // console.log("i am ",red)
// red.addEventListener("click", function() {
//     console.log("i am red");
//     alert("i am red");
// });



// let yellow=document.getElementById("second");
// // console.log("i am ",yellow)
// yellow.addEventListener("click", function() {
//     console.log("i am yellow");
//     alert("i am yellow");
// });



// let Green=document.getElementById("third");
// // console.log("i am ",green)
// Green.addEventListener("click", function() {
//     console.log("i am green");
//     alert("i am green");
// });


let countRed=document.getElementById("first");

let countR=0;
countRed.addEventListener("mouseover", function() {
    console.log("i am red");
    countR ++;
   console.log("count:=",countR);
   alert("Count of red mouseover is : " + countR);
});


let countYellow=document.getElementById("second");
let countY=0;
countYellow.addEventListener("mouseover", function() {
    console.log("i am yellow");
    countY ++;
   console.log("count:=",countY);
   alert("Count: " + countY);
});


