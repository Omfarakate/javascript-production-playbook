let fadeTarget = document.getElementById("JsTarget");
let fadeOutId=document.getElementById("101");
fadeOutId.addEventListener("click",function(){
     let opacity = 1; 
  let fadeEffect = setInterval(function () {
    if (opacity > 0) {
      opacity -= 0.1;
      fadeTarget.style.opacity = opacity;
    } else {
      clearInterval(fadeEffect);
    }
  }, 500);
});

let fadeInTarget=document.getElementById("JsTarget");
let fadeInId=document.getElementById("102");
fadeInId.addEventListener("click",function(){
    let opacity=-0.5;
    let fadeInEffect=setInterval(function(){
        if(opacity<=1){
            opacity+=0.2;
            fadeInTarget.style.opacity=opacity;
        }
        else{
            clearInterval(fadeInEffect);
        }
    },500);
})

