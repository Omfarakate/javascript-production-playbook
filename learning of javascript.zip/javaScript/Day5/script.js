document.addEventListener("DOMContentLoaded",function(){
    let formContent=document.getElementById("my_form");
    formContent.addEventListener("submit",function(event){
        event.preventDefault();
        const formdata=new FormData(this);
          
        const firstName=formdata.get("first_name");
        const lastName=formdata.get("last_name");
        const Email=formdata.get("email");
        const userName=formdata.get("username");
        const profileImage=formdata.get("profile_image");
        const password = formdata.get("password");

           if (!firstName || !Email || !userName || !password || !profileImage) {
            alert('All fields are required!');
        } else {
            console.log("Form submitted successfully!");
        }

        const customerDetails= {
            firstName,
            lastName,
            Email,
            userName,
            password,
            profileImage
        }
        const apiUrl="http://202.131.123.86:8082/ajira_services/WS/customer_add";
        console.log(apiUrl);
        fetch(apiUrl,{
            method:"POST",
            body:formdata
        }).then((response)=>{
            response.json()
            .then((data)=>{
                console.log(data);
                if(data.settings.success==1){
                    const customerId = data["http://202.131.123.86:8082/ajira_services/WS/customer_detail?customer_id"];
                    window.location.href = "http://localhost//javaScript/Day5/details.html"+customerId;
                }
                else{
                    alert("failed to add data");
                }
            }).catch((err)=>{
                alert("failed to add data")&& console.error(err);
            })
        }).catch((err)=>{
                alert("failed to add data")&& console.error(err);
            })
    })

     
})