document.addEventListener("DOMContentLoaded", function() {
    const addTaskBtn = document.getElementById("Add_Btn");
    const taskInput = document.getElementById("my_task"); 
    const section = document.getElementById("action_place");
    const clearAllBtn = document.getElementById("clear_Btn");

    let tasks = JSON.parse(localStorage.getItem("myTasks")) || [];
    functionTask();


    function functionTask() {
        section.innerHTML = ""; 
         for (let i = 0; i < tasks.length; i++) {
        const div = document.createElement('div');
        div.innerHTML = `
            <span>${tasks[i]}</span>
            <button onclick="deleteTask(${i})">delet</button>
        `;
        section.appendChild(div);
    }
        localStorage.setItem("myTasks", JSON.stringify(tasks));
    }

    addTaskBtn.addEventListener("click", function() {
        if (taskInput.value !== "") {
            tasks.push(taskInput.value);
            taskInput.value = "";
            functionTask();
        }
    });

 
    window.deleteTask = function(index) {
        tasks.splice(index, 1);
        functionTask();
    };

    clearAllBtn.addEventListener("click", function() {
        tasks = [];
        functionTask();
    });
});
