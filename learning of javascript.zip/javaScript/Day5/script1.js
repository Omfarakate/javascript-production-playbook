const apiUrl = "http://202.131.123.86:8082/ajira_services/WS/get_countries";

async function fetchCountries() {
    const messageDiv = document.getElementById("message");
    const table = document.getElementById("countryTable");
    const tbody = table.querySelector("tbody");

    try {
        messageDiv.textContent = "Loading countries...";
        messageDiv.className = "loading";

        const response = await fetch(apiUrl);

       if (!response.ok) {
            throw new Error(`HTTP Error! Status: ${response.status}`);
        }

        const result = await response.json();

        const countries = result.data;

        tbody.innerHTML = "";

        countries.forEach((country, index) => {
            const row = document.createElement("tr");

            row.innerHTML = `
                    <td>${index + 1}</td>
                    <td>${country.mc_country}</td>
                    <td>${country.mc_country_code}</td>
                `;

            tbody.appendChild(row);
        });

        messageDiv.style.display = "none";
        table.style.display = "table";

    } catch (error) {
        messageDiv.textContent = "Error loading countries: " + error.message;
        messageDiv.className = "error";
        table.style.display = "none";
    }
}

window.addEventListener("DOMContentLoaded", fetchCountries);