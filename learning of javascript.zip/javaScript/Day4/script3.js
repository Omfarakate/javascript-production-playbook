document.addEventListener("DOMContentLoaded",function(){
    window.addEventListener("keypress",function(event){
        const newBlock=document.createElement("div");
        newBlock.classList.add("div");
        newBlock.setAttribute("name","unknown");
        
        const oldBlock=document.querySelector("#mainDiv");
        const parentDiv=oldBlock.parentNode;
        // parentDiv.insertBefore(newBlock,oldBlock);
        oldBlock.after(newBlock);
    })
})