const myElement = document.getElementById('myDiv');



// myElement.addEventListener("keypress",function(){
//     console.log("i am here ");
//     myElement.style.color = 'blue';
//     myElement.style.backgroundColor = 'yellow';
//     myElement.style.fontSize = '20px';
//     myElement.style.borderBlock='black';
// })
// or

window.addEventListener("keypress",function(){
    console.log("i am here ");
   Object.assign(myElement.style, {
  color: 'blue',
  backgroundColor: 'red',
  fontSize: '20px'
});
})




