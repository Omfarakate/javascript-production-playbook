const imageArray = [
  '/var/www/html/javaScript/Day4/1.jpg',
  '/var/www/html/javaScript/Day4/2.jpg',
  '/var/www/html/javaScript/Day4/3.jpg',
];

const thumbBar = document.querySelector('.gallery');
const mainImg = document.querySelector('#featured');
const prevBtn = document.querySelector('.prev-btn');
const nextBtn = document.querySelector('.next-btn');


const lightbox = document.getElementById('lightbox');
const modalImg = document.getElementById('modalImg');
const closeBtn = document.querySelector('.close');

let currentIndex = 0;


imageArray.forEach((src, index) => {
    const newImage = document.createElement('img');
    newImage.src = src;
    newImage.style.width = "100px";
    newImage.style.cursor = "pointer";
    

    newImage.addEventListener('click', () => {
        updateDisplay(index);
    });
    
    thumbBar.appendChild(newImage);
});


function updateDisplay(index) {
  currentIndex = index;
  mainImg.src = imageArray[currentIndex];
}


prevBtn.addEventListener('click', () => {
  currentIndex = (currentIndex === 0) ? imageArray.length - 1 : currentIndex - 1;
  updateDisplay(currentIndex);
});

nextBtn.addEventListener('click', () => {
  currentIndex = (currentIndex === imageArray.length - 1) ? 0 : currentIndex + 1;
  updateDisplay(currentIndex);
});


mainImg.addEventListener('click', () => {
    lightbox.style.display = "block";
    modalImg.src = mainImg.src;
});

closeBtn.addEventListener('click', () => {
    lightbox.style.display = "none";
});


window.onclick = (event) => {
    if (event.target == lightbox) lightbox.style.display = "none";
};
