
let mainForm=document.getElementById('customForm');

mainForm.addEventListener('submit', function(event) {
      event.preventDefault();
  let isValid = true;

  const name = document.getElementById('username').value;
  const nameError = document.getElementById('nameError');
  if (name === "") {
    nameError.textContent = "Name is required.";
    isValid = false;
  } else {
    nameError.textContent = "";
  }

  const country = document.getElementById('country').value;
  const countryError = document.getElementById('countryError');
  if (country === "") {
    countryError.textContent = "Please select a country.";
    isValid = false;      
  } else {
    countryError.textContent = "";
  }

  const gender = document.querySelector('input[name="gender"]:checked');
  const genderError = document.getElementById('genderError');
  if (!gender) {
    genderError.textContent = "Please select your gender.";
    isValid = false;
  } else {
    genderError.textContent = "";
  }

  const terms = document.getElementById('terms').checked;
  const termsError = document.getElementById('termsError');
  if (!terms) {
    termsError.textContent = "You must agree to the terms.";
    isValid = false;
  } else {
    termsError.textContent = "";
  }


  if (isValid) {
    alert("Form submitted successfully!"); 
  }
});
