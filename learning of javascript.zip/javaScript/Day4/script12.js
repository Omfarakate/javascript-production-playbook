

let calButton=document.getElementById("102");
calButton.addEventListener("click",function(){
const v1 = document.getElementById('num1').value;
    const v2 = document.getElementById('num2').value;
    const op = document.getElementById('operator').value;
    const out = document.getElementById('output');

    const n1 = parseFloat(v1), n2 = parseFloat(v2);
    let res;
    
    switch (op) {
        case "+": res = n1 + n2; break;
        case "-": res = n1 - n2; break;
        case "*": res = n1 * n2; break;
        case "/": res = n2 !== 0 ? n1 / n2 : "Error: Div by 0"; break;
    }
    out.innerText = `Result: ${res}`;

})
