document.addEventListener("DOMContentLoaded", function() {
    const form = document.querySelector("form");
    
    form.addEventListener("submit", function(event) {
        event.preventDefault();
        const formdata = new FormData(this);
        for (const [key, value] of formdata.entries()) {
            console.log(`${key}: ${value}`);
        }
        const username = formdata.get("username");
        const password = formdata.get("pwd");

        if (!username || !password) {
            alert('All fields are required!');
        } else {
            console.log("Form submitted successfully!");
        }
    });
});
