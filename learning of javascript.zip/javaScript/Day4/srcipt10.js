const myForm = document.getElementById('myForm');
const outputDiv = document.getElementById('output');
const sbutton=document.getElementById("btn");

sbutton.addEventListener("click",function(){
    console.log("i am Here");
    let results;
 for (let att in myForm.attributes) {
    let attribute = myForm.attributes[att];
    console.log("i am here");
    if (attribute.name !== undefined) {
        let name = attribute.name;
        let value = attribute.value;
        
        if (name === "action" || name === "name" || name === "method") {
            results += `<li><strong>${name}: ${value}</strong></li>`;
        } else {
            results += `<li>${name}: ${value}</li>`;
        }
    }
}

outputDiv.innerHTML = results;
})


