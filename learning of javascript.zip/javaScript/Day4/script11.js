// // const selectedDate = document.querySelector('#datePicker');
// // const displayDate = document.querySelector('#display');
// const form = document.getElementById("surveyForm");
// const resultsTableBody = document.querySelector("#resultsTable tbody");
// const errorMsg = document.getElementById("error");
// let responseCount = 0;

// form.addEventListener("submit", function(event) {
//   event.preventDefault();

//   const selectedRating = document.querySelector('input[name="rating"]:checked');

//   if (!selectedRating) {
//     errorMsg.style.display = "block";
//     return; 
//   }

//   errorMsg.style.display = "none";
//   responseCount++;

//   const newRow = resultsTableBody.insertRow();
//   newRow.insertCell(0).innerText = responseCount;
//   newRow.insertCell(1).innerText = selectedRating.value;

// //   form.reset();
// });

// // selectedDate.addEventListener('change', (e) => {
// // displayDate.textContent = e.target.value;
// // });