let mainDiv=document.getElementById("121");
window.addEventListener("keypress",function(){
    console.log("i am here ");
    mainDiv.style.position="fixed";
    mainDiv.style.zIndex=1000;
    mainDiv.style.backgroundColor="aqua";
    mainDiv.style.opacity=0.5;
})
