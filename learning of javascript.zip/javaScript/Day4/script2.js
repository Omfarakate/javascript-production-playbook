document.addEventListener("DOMContentLoaded", function() {
    const allDivs = document.querySelectorAll('div');
  //     window.addEventListener("keypress",function(){
  //       for (const existingDiv of allDivs) {
  //   const newDiv = document.createElement('div');

  //   newDiv.textContent = 'I am a new after  div!';
  //   newDiv.style.backgroundColor = 'lightblue';

  //   existingDiv.insertBefore(newDiv);
  //   }
  // })
    
    window.addEventListener("keypress",function(){
        for (const existingDiv of allDivs) {
    const newDiv = document.createElement('div');

    newDiv.textContent = 'I am a new inner div!';
    newDiv.style.backgroundColor = 'lightblue';

    existingDiv.appendChild(newDiv);
    }
  })
  window.addEventListener("keypress",function(){
        for (const existingDiv of allDivs) {
    const newDiv = document.createElement('div');

    newDiv.textContent = 'I am a new after  div!';
    newDiv.style.backgroundColor = 'lightblue';

    existingDiv.after(newDiv);
    }
  })
    
});







