document.addEventListener("DOMContentLoaded", function () {

    let button = document.getElementById("Calculate");

    const startYear = 1900;
    const endYear = new Date().getFullYear();
    const select = document.getElementById("year-select");

    for (let i = endYear; i >= startYear; i--) {
        const option = document.createElement("option");
        option.value = i;
        option.text = i;
        select.add(option);
    }

    button.addEventListener("click", function () {

        let monthInput = document.getElementById("month").value;
        let day = document.getElementById("number").value;
        let year = select.value;

        if (monthInput === "" || day === "") {
            alert("Please enter full birthday");
            return;
        }

        

        let month = monthInput.split("-")[1] - 1;

        let birthDate = new Date(year, month, day);
        let currentDate = new Date();

        let diff = currentDate - birthDate;

        let seconds = Math.floor(diff / 1000);
        let minutes = Math.floor(seconds / 60);
        let hours = Math.floor(minutes / 60);
        let days = Math.floor(hours / 24);
        let weeks = Math.floor(days / 7);
        let months = Math.floor(days / 30.4375);
        let years = Math.floor(days / 365.2425);

        console.log(years + " years old");
        console.log(months + " months old");
        console.log(weeks + " weeks old");
        console.log(days + " days old");
        console.log(hours + " hours old");
        console.log(minutes + " minutes old");
        console.log(seconds + " seconds old");

        let mainContainer = document.querySelector(".mainContainer");

        let newDiv = document.createElement("div");
        newDiv.classList.add("report");

        newDiv.innerHTML =
            `You are ${years} years old <br><br>
            or ${months} months old <br>
            or ${weeks} weeks old <br>
            or ${days} days old <br>
            or ${hours} hours old <br>
            or ${minutes} minutes old <br>
            or ${seconds} seconds old <br><br>`;

        mainContainer.appendChild(newDiv);

        let nextBirthday = new Date(currentDate.getFullYear(), month, day);

        if (nextBirthday < currentDate) {
            nextBirthday.setFullYear(currentDate.getFullYear() + 1);
        }

        let diffNext = nextBirthday - currentDate;

        let nSeconds = Math.floor(diffNext / 1000);
        let nMinutes = Math.floor(nSeconds / 60);
        let nHours = Math.floor(nMinutes / 60);
        let nDays = Math.floor(nHours / 24);

        nHours = nHours % 24;
        nMinutes = nMinutes % 60;
        nSeconds = nSeconds % 60;

        let nextText = document.createElement("div");

        nextText.innerHTML =
            `And your next birthday is in:<br>
            ${nDays} days ${nHours} hrs ${nMinutes} mins ${nSeconds} secs`;

        newDiv.appendChild(nextText);

    });

});