
// Notification manager

// function main() {
//   const NotificationManager = {
//     setIds: new Set(),
//     add(message, duration) {
//       const id = Date.now() + Math.random();
//       const delay = Number(duration);
      
//       console.log(`ID: ${id} | Message: "${message}" (${delay} ms)`);

//       const timerId = setTimeout(() => {
//         this.remove(timerId);
//       }, delay);

//       this.setIds.add(timerId);
//       console.log(`Active Notifications:`, this.setIds.size);
//     },

//     remove(timerId) {
//       if (this.setIds.has(timerId)) {
//         clearTimeout(timerId); 
//         this.setIds.delete(timerId);
//         console.log(`REMOVED Timer ID: ${timerId}`);
//       }
//     },

//     clearAll() {
//       console.log("Clearing all notifications...");
//       this.setIds.forEach((timerId) => clearTimeout(timerId));
//       this.setIds.clear();
//       console.log("System wiped.");
//     }
//   };

//   const userMsg = prompt("Enter your notification message:");
//   const userDuration = prompt("Enter duration in milliseconds ")*1000;

//   if (userMsg && userDuration) {
//     NotificationManager.add(userMsg, userDuration);
//   } else {
//     console.log("Input cancelled.");
//   }
//   setTimeout(() => {
//     NotificationManager.clearAll();
//   }, 10000);
// }

// main();
// const originalObj={

// }
// const updates={

// }
// function deepUpdates(originalObj,updates){
    
// }



// function main3(){
//     let command=prompt("Enter the command as ADD_IP, REMOVE_IP, or CHECK_IP");
//     const config = {
//         version: "144"
//     };
//     const System={
//     authorizedIds: new Set(),
//     }
//     console.log(System);
//     console.log(System.authorizedIds);
//     Object.freeze(config);
//     switch(command){
//                 case "ADD_IP":
//                     let ip=prompt("Enter ip");
//                     System.authorizedIds.add(ip);
//                     alert("Adding ip sucessfull");
//                     break;
//                 case "REMOVE_IP":
//                     let removeIp=prompt("Enter ip");
//                     if(System.authorizedIds.has(removeIp)){
//                         System.authorizedIds.delete(removeIp);
//                     alert("Removing ip sucessfull");
//                     }
                    
//                     break;
//                 case "CHECK_IP":
//                     let checkIp=prompt("Enter ip");
//                     if(System.authorizedIds.has(checkIp)){
//                     console.log("yes ip is present ");
//                     alert("ip is present")
//                     }
//                     else{
//                         console.log("the ip is not present");
//                         alert("Ip is not present");
//                     }
//                     break;
                           
//             }
// }
// main3();


// 4)console based digital clock;
// function startClock() {
//     const now = new Date();

//     const timeString = now.toLocaleTimeString();
//     console.clear();
//     console.log("Current Time:", timeString);
//     //let x=setTimeout(startClock,5000);
//     setInterval(startClock,1000);
//     //console.log(x);

// }

// startClock();



// 5) palindrome

// function checkPalindrome(){
//  let str=prompt("Enter the string to check palindrome");
//  let Rstr="";
//     for(let i=str.length;i>=0;i--){
//     Rstr+=str.charAt(i);
//     }
//     if(str===Rstr){
//         console.log("Given String is palindrome");
//     }
//     else{
//         console.log("the given string is not palindrome");
//     }
// }

// checkPalindrome();

// 6) reverse by chacracter reverse by Word

// function reverseByCharacter(){
//     let str="We will win the world cup."
//     let Rstr="";
//     for(let i=str.length;i>=0;i--){
//     Rstr+=str.charAt(i);
//     }
//     console.log(Rstr);
// }
// reverseByCharacter();

// function reverseWords(str) {

//     const words = str.split(' ');
//     words.reverse();
//     const reversedString = words.join(' ');
  
//     return reversedString;
// }
// let str="We will win the world cup."

// console.log(reverseWords(str));


// 7)ocurrencePosition
// function ocurrencePosition(){
//     let str="India has a very good hope to win world cup.";
//     let findingLetter=prompt("Enter finding letter");
//     let count=0;
//     for(let i=0;i<str.length;i++){
//         if(str.charAt(i)===findingLetter){
//             count++;
//             console.log(count+"occurrence of the 'a' is at position:",i)
//         }

//     }
//     console.log(count);
// }
// ocurrencePosition();

// 8)calculateAge
// function calculateAge(){
// let birthYear=parseInt(prompt("Enter the birt year only"));
// const currentDate = new Date();
// let currentYear=currentDate.getFullYear();
// let age=currentYear-birthYear;
// alert(age);
// console.log("Your Age is",age);
// console.log(currentDate);
// }
// calculateAge();

// 10)simpleCalculator
// function simpleCalculator() {
//     let num1 = Number(prompt("Enter the first number"));
//     let num2 = Number(prompt("Enter the second number"));
//     let operation = prompt("Enter operation (+, -, *, /)");
//     let result;

//     switch (operation) {
//         case "+":
//             result = num1 + num2;
//             break;

//         case "-":
//             result = num1 - num2;
//             break;

//         case "*":
//             result = num1 * num2;
//             break;

//         case "/":
//             result = num1 / num2;
//             break;

//         default:
//             result = "Invalid operation";
//     }
//     alert("Result: " + result);
// }
// simpleCalculator();

// 11)Guess the number
//     function guessNumber(){
//         let num=Number(prompt("Guess a number between 1 and 100:"));
//         let gameNumber=Math.floor(Math.random() * 100) + 1;    
//         if(num===gameNumber){
//             console.log("Your guess is correct ");
//         }
//         else if(num<gameNumber){
//             console.log("Your Entered number is too low");
//         }
//         else if(num>gameNumber){
//             console.log("Your guess is too high");
//         }
//         else {
//             console.log(" Please enter a valid number.");
//         }
// console.log(gameNumber);
//     }
// guessNumber();
  