

document.addEventListener("DOMContentLoaded",function(){
    let button=document.getElementById("Calculate");
       const startYear = 1900;
    const endYear = new Date().getFullYear();
    const select = document.getElementById('year-select');

    for (let i = endYear; i >= startYear; i--) {
        const option = document.createElement('option');
        option.value = i;
        option.text = i;
        select.add(option);
    }
    button.addEventListener("click",function(){
        console.log("here");
        let month=document.getElementById("month").value;
        let date=document.getElementById("number").value;
        //  select 
        let currentDate=new Date();
        let currentYear=currentDate.getFullYear();
        // console.log(currentDate);
        // console.log(select.value);
        console.log(currentYear)
        let age=currentYear-select.value;
        console.log(age);

        let months=age*12;
        console.log(months+"months old")

        let weeks=age*(365.2425/7)//or *(52.1775)
        console.log(weeks+"weeks old");

        let Days=age*365.2425;
        console.log(Days+"days old");

        let Hours=Days*24;
        console.log(Hours+"Hours old");

        let Minutes=Hours*60;
        console.log(Minutes+"Minutes old");

        let Seconds=Minutes*60;
        console.log(Seconds+"Seconds old");

        let Milliseconds=Seconds*1000;
        console.log(Milliseconds+"Milliseconds old");
        
        const totalAge={
            age,
            months

        }

        let mainContainer=document.querySelector(".mainContainer");
        let newDiv=document.createElement("div");
        newDiv.classList.add("report");
        newDiv.textContentContent = `Age: ${totalAge.age} years, ${totalAge.months} months`;
        mainContainer.appendChild(newDiv);

        


 
    })
})