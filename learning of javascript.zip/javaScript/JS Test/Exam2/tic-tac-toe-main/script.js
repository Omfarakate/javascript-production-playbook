
let boxes= document.querySelectorAll(".box");
let resetBtn=document.querySelector("#reset-btn");
let newGameBtn=document.querySelector("#new-btn");
let msgContainer=document.querySelector(".msg-container");
let msg=document.querySelector("#msg");

let turnO =true
let count=0;

let currentTurn=document.getElementById("currentTurn");
function turnFunc(x){
    if(x=true){
    currentTurn.textContent="O";
    }
    else{
    currentTurn.textContent="X";
    }
};

const winPattern=[
    [0,1,2],
    [0,3,6],
    [0,4,8],
    [1,4,7],
    [2,5,8],
    [2,4,6],
    [3,4,5],
    [6,7,8]
];
turnFunc(true);

boxes.forEach((box)=>{
    box.addEventListener("click",()=>{
        turnFunc();
        if(turnO){
            box.innerText="O";
            turnO=false;
            turnFunc(turnO);
        }else{
            box.innerText="X";
            turnO=true;
            turnFunc(turnO);
        }
        box.disabled=true;
        count++;
        turnFunc();

        let isWinner=checkWinner();

        if (count === 9 && !isWinner) {
      gameDraw();
    }
    });
});

const gameDraw = () => {
  msg.innerText = "Game was a Draw.";
  msgContainer.classList.remove("hide");
  disableBoxes();
  console.log("here");
};

const resetGame=()=>{
	box.disabled=false;
    enableBoxes();
    count=0;
    msgContainer.classList.add("hide");
    console.log("here");
};

const disableBoxes=()=>{
 for(let box of boxes){
    box.disable=true;
 }
};

const enableBoxes=()=>{
 for(let box of boxes){
    box.disable=false;
    box.innerText="";
    turnFunc();

 }
};

const showWinner=(winner)=>{
    msg.innerText = `Congratulation, Winner is ${winner}`;
    msgContainer.classList.remove("hide");
    disableBoxes();
};

const checkWinner=()=>{
    for(let pattern of winPattern){
        let pos1Val=boxes[pattern[0]].innerText;
        let pos2Val=boxes[pattern[1]].innerText;
        let pos3Val=boxes[pattern[2]].innerText;
        
        if(pos1Val!=""&&pos2Val!=""&&pos3Val!=""){
            if(pos1Val===pos2Val&&pos2Val===pos3Val){
                showWinner(pos1Val);
                return true;
            }
        }
    }
};

newGameBtn.addEventListener("click",resetGame);
resetBtn.addEventListener("click",resetGame);
