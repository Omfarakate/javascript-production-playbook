document.addEventListener("DOMContentLoaded", function () {

let stick = document.getElementById("stick");
let game = document.getElementById("game");
let scoreBox = document.getElementById("score");

let position = 300;
let score = 0;
let balloons = [];


document.addEventListener("keydown", function(e){

    if(e.key === "ArrowLeft"){
        position -= 30;
        if(position < 0) position = 0;
    }

    if(e.key === "ArrowRight"){
        position += 30;
        if(position > window.innerWidth - 300)
            position = window.innerWidth - 300;
    }

    stick.style.left = position + "px";
    
});


function createBalloon(){

    if(balloons.length >= 3) {
        return;
    }

    let balloon = document.createElement("div");
    balloon.classList.add("pos_abs");

    balloon.style.left = Math.random() * (window.innerWidth-100) + "px";
    balloon.style.top = window.innerHeight + "px";

    game.appendChild(balloon);

    balloons.push({
        element:balloon,
        speed: Math.random()*3 + 2
    });

}


function animate(){

    let stickRect = stick.getBoundingClientRect();

    for (let i = balloons.length - 1; i >= 0; i--) {

    let b = balloons[i];
    let el = b.element;

    let top = parseFloat(el.style.top);
    top = top - b.speed;
    el.style.top = top + "px";

    let rect = el.getBoundingClientRect();

    if (
        rect.top <= stickRect.bottom &&
        rect.right >= stickRect.left &&
        rect.left <= stickRect.right
    ) {
        el.remove();
        balloons.splice(i, 1);

        score++;
        scoreBox.innerHTML = "Score: " + score;
    }
    if (rect.top <= 0) {
        alert("Game Over! Score: " + score);
        location.reload();
        
        clearInterval(a);
        clearInterval(d);
        exit();
    }
}
  
}

let a=setInterval(createBalloon,1000);

let d=setInterval(animate,30);

});