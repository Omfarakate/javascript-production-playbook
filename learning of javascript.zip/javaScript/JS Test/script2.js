document.addEventListener("DOMContentLoaded", function () {

let availableNumbers = [];
let calledNumbers = [];
let playerTickets = [];
let marked = {};

const board = document.getElementById("masterBoard");
const ticketDiv = document.getElementById("ticket");
const winnerDiv = document.getElementById("winner");
const currentNumber = document.getElementById("currentNumber");

for (let i = 1; i <= 90; i++) {
    availableNumbers.push(i);

    const cell = document.createElement("div");
    cell.className = "masterCell";
    cell.id = "m" + i;
    cell.textContent = i;
    board.appendChild(cell);
}

function getRandomNumber() {

    if (availableNumbers.length === 0) return null;

    const index = Math.floor(Math.random() * availableNumbers.length);
    const number = availableNumbers[index];

    availableNumbers.splice(index, 1);

    calledNumbers.push(number);

    return number;
}


function generateTicket() {

  let ticket = [];
for (let i = 0; i < 3; i++) {
  let row = [];
  for (let j = 0; j < 9; j++) {
    row.push("");
  }
  ticket.push(row);
}

    let used = new Set();

    for (let row = 0; row < 3; row++) {

        let count = 0;

        while (count < 5) {

            let col = Math.floor(Math.random() * 9);

            if (ticket[row][col] === "") {

                let min = col * 10 + 1;
                let max = (col === 8) ? 90 : (col + 1) * 10;

                let num;

                do {
                    num = Math.floor(Math.random() * (max - min + 1)) + min;
                } while (used.has(num));

                used.add(num);

                ticket[row][col] = num;

                count++;
            }
        }
    }

    for (let col = 0; col < 9; col++) {

        let columnNums = [];

        for (let row = 0; row < 3; row++) {
            if (ticket[row][col] !== "") {
                columnNums.push(ticket[row][col]);
            }
        }

        columnNums.sort((a,b)=>a-b);

        let index = 0;

        for (let row = 0; row < 3; row++) {
            if (ticket[row][col] !== "") {
                ticket[row][col] = columnNums[index++];
            }
        }
    }

    return ticket;
}


function displayTicket(ticket) {

    ticketDiv.innerHTML = "";

    for (let i=0;i<3;i++) {

        for (let j=0;j<9;j++) {

            const cell = document.createElement("div");
            cell.className = "ticketCell";

            if(ticket[i][j] !== ""){

                cell.textContent = ticket[i][j];
                cell.id = "t_" + ticket[i][j];
            }

            ticketDiv.appendChild(cell);
        }
    }
}


document.getElementById("playersTicket").addEventListener("click", function(){

    const ticket = generateTicket();

    playerTickets = ticket;

    displayTicket(ticket);

});


document.getElementById("generate").addEventListener("click", function(){

    const number = getRandomNumber();

    if(number === null){
        alert("All numbers called");
        return;
    }

    currentNumber.textContent = number;

    const boardCell = document.getElementById("m"+number);

    boardCell.classList.add("called");

    const ticketCell = document.getElementById("t_"+number);

    if(ticketCell){
        ticketCell.classList.add("marked");
        marked[number] = true;
    }

    checkWinner();
});


function checkWinner(){

    let markedCount = Object.keys(marked).length;

    if(markedCount >=5){
        winnerDiv.innerHTML = "🎉 Early Five Achieved!";
    }

    checkLines();

    if(markedCount === 15){
        winnerDiv.innerHTML += "<br>🏆 Full House!";
    }
}


function checkLines(){

    for(let row=0;row<3;row++){

        let complete = true;

        for(let col=0;col<9;col++){

            let num = playerTickets[row][col];

            if(num !== "" && !marked[num]){
                complete = false;
            }
        }

        if(complete){

            if(row===0) winnerDiv.innerHTML += "<br>Top Line Win!";
            if(row===1) winnerDiv.innerHTML += "<br>Middle Line Win!";
            if(row===2) winnerDiv.innerHTML += "<br>Bottom Line Win!";
        }
    }
}

});