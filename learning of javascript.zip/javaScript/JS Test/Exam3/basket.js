document.addEventListener("DOMContentLoaded", function () {

    let mainBasket = document.querySelector(".circles-row");
for (let i = 1; i <= 10; i++) {
    let circle = document.createElement("div");
    circle.classList.add("circle");
    circle.textContent = i;
    mainBasket.appendChild(circle);
}
let Balls = document.querySelectorAll(".circle");


let box1 = document.querySelector(".border-black");
let box2 = document.querySelector(".border-green");
let box3 = document.querySelector(".border-purple");

let selectedBasket = null;

let timer=0;
let preventClick=false;
box1.addEventListener("click", function () {
         selectedBasket = box1;

       
});

box2.addEventListener("click", function () {

         selectedBasket = box2;
    
  });

box3.addEventListener("click", function () {
         selectedBasket = box3;
        
       
 });

for (let i = 0; i < Balls.length; i++) {

    let ball = Balls[i];
    ball.addEventListener("click", function () {
        timer=setTimeout(function(){
        if (selectedBasket) {
            selectedBasket.append(ball);
        }
        preventClick=false;
    },250);
        
        

    });

    ball.addEventListener("dblclick", function () {
        clearTimeout(timer);
        preventClick=true;
        selectedBasket = null;

        console.log(selectedBasket);

        mainBasket.append(ball);
        
        
    });

}

});