document.addEventListener("DOMContentLoaded",function(){
    let form=document.querySelector("form");
    const tableBody = document.getElementById("table_body");
    const searchBar = document.getElementById("search_bar");
    
    form.addEventListener("submit",function(e){
        e.preventDefault();

        let isValid=true;

        let ProductName=document.getElementById("product_name").value;
        let SkuId=document.getElementById("sku").value;
        let category=document.getElementById("category").value;
        let unitPrice=document.getElementById("unit_price").value;
        let stockQuantity=document.getElementById("stock_quantity").value;
        let expiryDate=document.getElementById("expiry_date").value;
        let status=document.getElementById("status").value;

        console.log("heyy");

        const skuRegex = /^Prod-\d{4}$/;

        const productNameError = document.getElementById('nameError');
        if (ProductName===""  ) {
            productNameError.textContent = "ProductName is required.";
            productNameError.style.color="red";
            isValid = false;
        } else {
            productNameError.textContent = "";
        }
        
      
        const UnitPriceError=document.getElementById("UnitPriceError");
        if(unitPrice==""){
            UnitPriceError.textContent="Unit price is required"
            UnitPriceError.style.color="red";
            isValid=false;
        }
        const skuidError=document.getElementById("sku");
        if (SkuId === "" || !skuRegex.test(SkuId)) { 
            skuidError.textContent = "SKU Id is required";
            skuidError.style.color = "red";
            isValid = false;
        }
 

        else{
            UnitPriceError.textContent="";
        }

        // if (!skuRegex.test(SkuId)) {
        //     alert("SKU must follow the format: Prod-1234");
        // }

        if ( category === "food" && !expiryDate) {
             alert("Expiry Date is required for Food items.");
        }

       
        let inventory = JSON.parse(localStorage.getItem("inventory")) || [];


        const isDuplicate = inventory.some(item => item.SkuId ===SkuId );

        if (isDuplicate && isValid==false ) {
             alert("Error: A product with this SKU already exists.");
        }else{
            const product={
            ProductName,
            SkuId,
            category,
            unitPrice,
            stockQuantity,
            expiryDate: expiryDate ,
            status: status || "Active"
        }
            inventory.push(product);
            console.log(product);

        localStorage.setItem("inventory", JSON.stringify(inventory));
       
        }

         if (isValid) {
        alert("Form submitted successfully!"); 
        }


         tableCall();
    })
    
    tableCall();

   function tableCall(filterText = "") {
    console.log("In table");

    const inventory = JSON.parse(localStorage.getItem("inventory")) || [];
    tableBody.innerHTML = "";

    const term = filterText.toLowerCase();

    const filteredData = inventory.filter(item =>
        item.ProductName?.toLowerCase().includes(term) ||
        item.category?.toLowerCase().includes(term)
    );

    filteredData.forEach(item => {
        tableBody.innerHTML += `
            <tr>
                <td>${item.ProductName}</td>
                <td>${item.SkuId}</td>
                <td>${item.category}</td>
                <td>${item.unitPrice}</td>
                <td>${item.stockQuantity}</td>
                <td>${item.expiryDate || "N/A"}</td>
                <td>${item.status}</td>
            </tr>
        `;
    });
}

     searchBar.addEventListener("input", (e) => {   
        tableCall(e.target.value);
    });

        
})
