document.addEventListener("DOMContentLoaded", function () {

const masterBoard = document.getElementById("masterBoard");
// const ticketDiv = document.getElementById("ticket");
// const ticketDiv2 = document.getElementById("ticket2");
// const winnerDiv = document.getElementById("winner");
// const winnerDiv2 = document.getElementById("winner2");

// let markedNumbers = [];
// let markedNumbers2 = [];

let playersTickets = [];
let playersMarked = [];



let number = 1;

while (number <= 90) {
    let box = document.createElement("div");
    box.className = "masterCell";
    box.id = "m" + number;
    box.innerHTML = number;

    masterBoard.appendChild(box);
    number++;
}


let availableNumbers = [];

for (let i = 1; i <= 90; i++) {
    availableNumbers.push(i);
}



function getRandomNumber() {

    if (availableNumbers.length === 0) return null;

    let randomIndex = Math.floor(Math.random() * availableNumbers.length);
    let randomNumber = availableNumbers[randomIndex];

    availableNumbers.splice(randomIndex, 1);

    return randomNumber;
}


function generateTicket() {

let ticket = [];
let usedNumbers = new Set();

for (let i = 0; i < 3; i++) {

    let row = [];

    for (let j = 0; j < 9; j++) {
        row.push("");
    }

    ticket.push(row);
}


let colIndexArr = [[], [], []];

for (let row = 0; row < 3; row++) {

let count = 0;

while (count < 5) {

let col = Math.floor(Math.random() * 9);

colIndexArr[row][count] = col;

let min = col * 10 + 1;
let max = (col === 8) ? 90 : (col + 1) * 10;

let number;

do {
number = Math.floor(Math.random() * (max - min + 1)) + min;
} while (usedNumbers.has(number));

usedNumbers.add(number);
ticket[row][col] = number;

count++;
}
}


for (let col = 0; col < 9; col++) {

if (ticket[0][col] === "" && ticket[1][col] === "" && ticket[2][col] === "") {

let row = Math.floor(Math.random() * 3);

let min = col * 10 + 1;
let max = (col === 8) ? 90 : (col + 1) * 10;

let number;

do {
number = Math.floor(Math.random() * (max - min + 1)) + min;
} while (usedNumbers.has(number));
displayTicket
usedNumbers.add(number);
ticket[row][col] = number;
}
}


for (let col = 0; col < 9; col++) {

let tempArray = [];

for (let row = 0; row < 3; row++) {
if (ticket[row][col] !== "") {
tempArray.push(ticket[row][col]);
}
}

tempArray.sort((a,b)=>a-b);

let index = 0;

for (let row = 0; row < 3; row++) {

if (ticket[row][col] !== "") {
ticket[row][col] = tempArray[index];
index++;
}
}

}

return ticket;

}


function displayTicket(ticketData, containerId, prefix) {

let container = document.getElementById(containerId);

container.innerHTML = "";

for (let i = 0; i < ticketData.length; i++) {

for (let j = 0; j < ticketData[i].length; j++) {

let cellDiv = document.createElement("div");

cellDiv.className = "ticketCell";

let cell = ticketData[i][j];

if (cell !== "") {

cellDiv.textContent = cell;
cellDiv.id = prefix + cell;

}

container.appendChild(cellDiv);

}
}

}


document.getElementById("playersTicket").addEventListener("click", function () {

let totalPlayers = document.getElementById("totalPlayers").value;

let allPlayersDiv = document.getElementById("allPlayers");

allPlayersDiv.innerHTML = "";

playersTickets = [];
playersMarked = [];

for (let p = 0; p < totalPlayers; p++) {

let ticketData = generateTicket();

playersTickets.push(ticketData);
playersMarked.push([]);

let ticketContainer = document.createElement("div");
ticketContainer.className = "playerTicket";

for (let i = 0; i < ticketData.length; i++) {

for (let j = 0; j < ticketData[i].length; j++) {

let cell = document.createElement("div");

cell.className = "ticketCell";

if (ticketData[i][j] !== "") {

cell.innerText = ticketData[i][j];
cell.id = "p" + p + "n" + ticketData[i][j];

}

ticketContainer.appendChild(cell);

}
}

allPlayersDiv.appendChild(ticketContainer);

}

});


document.getElementById("generate").addEventListener("click", function () {

const number = getRandomNumber();

if (number === null) {

alert("All numbers called!");
return;

}


document.getElementById("currentNumber").textContent = number;


let boardCell = document.getElementById("m" + number);

if (boardCell) boardCell.classList.add("called");


for (let p = 0; p < playersTickets.length; p++) {

let ticketCell = document.getElementById("p" + p + "n" + number);

if (ticketCell) {

ticketCell.classList.add("marked");
playersMarked[p].push(number);

}

}

checkAllPlayersWinner();

});


function checkAllPlayersWinner() {

let winnerBoard = document.getElementById("winnerBoard");

for (let p = 0; p < playersMarked.length; p++) {

if (playersMarked[p].length === 5) {

let msg = document.createElement("div");
msg.innerText = "Player " + (p + 1) + " - Early Five Winner ";
winnerBoard.appendChild(msg);

}

if (playersMarked[p].length === 15) {

let msg = document.createElement("div");
msg.innerText = "Player " + (p + 1) + " - Full House Winner ";
winnerBoard.appendChild(msg);

}

}

}

});